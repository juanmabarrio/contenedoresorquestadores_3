No pude hacer la anterior por lo que esta me ha costado más de lo debido. Además, lo he estado intentando pero no consigo que el worker conecte a la base de datos. 
Ya he llegado al nivel de frustración alta y no tuve tiempo para consultar en Slack.
He incluido los 6 manifiests en el directorio "manifests". Espero con ganas la solución. 
